﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DemoWebShopTests.PageObjects
{
    class MainMenuPageObject
    {
        private IWebDriver _webDriver;

        private readonly By _registerButton = By.XPath("//a[@class= 'ico-register']");

        private readonly By _contactUsButton = By.XPath("//a[@href='/contactus']");
        private readonly By _contactMessageBox = By.XPath("//textarea[@name='Enquiry']");
        private readonly By _submitButton = By.XPath("//input[@name='send-email']");
        

        private readonly By _siteMapButton = By.XPath("//a[@href='/sitemap']");
        private readonly By _shippingReturnsButton = By.XPath("//a[@href='/shipping-returns']");
        private readonly By _privacyPolicyButton = By.XPath("//a[@href='/privacy-policy']");
        private readonly By _conditionsOfUseButton = By.XPath("//a[@href='/conditions-of-use']");
        private readonly By _aboutUsButton = By.XPath("//a[@href='/about-us']");
        private readonly By _contactUsFooterButton = By.XPath("//a[@href='/contactus']");
        private readonly By _searchButton = By.XPath("//a[@href='/search']");
        private readonly By _newsButton = By.XPath("//a[@href='/news']");
        private readonly By _blogButton = By.XPath("//a[@href='/blog']");
        private readonly By _recentlyViewedButton = By.XPath("//a[@href='/recentlyviewedproducts']");
        private readonly By _compareProductsButton = By.XPath("//a[@href='/compareproducts']");
        private readonly By _newProductsButton = By.XPath("//a[@href='/newproducts']");
        private readonly By _myAccountButton = By.XPath("//a[@href='/customer/info']");
        private readonly By _ordersButton = By.XPath("//a[@href='/customer/orders']");
        private readonly By _myAdressesButton = By.XPath("//a[@href='/customer/adresses']");
        private readonly By _myCartButton = By.XPath("//a[@href='/cart']");
        private readonly By _wishlistButton = By.XPath("//a[@href='/wishlist']");

        public MainMenuPageObject(IWebDriver webDriver)
        {
            _webDriver = webDriver;
        }

        public RegistrationPageObject Registration()
        {
            _webDriver.FindElement(_registerButton).Click();
            return new RegistrationPageObject(_webDriver);
        }

        public ItemsPageObject Items()
        {
            Thread.Sleep(4000);
            return new ItemsPageObject(_webDriver);
        }

       
    public void ContactUs ()
        {
        _webDriver.FindElement(_contactUsButton).Click();
           // _webDriver.FindElement(_contactMessageBox).SendKeys();
           // не смогла разобраться, как вставить Random message в sendkeys
         
            Thread.Sleep(4000);
            _webDriver.FindElement(_submitButton);
           
        }

        public void Footer()
        {
            _webDriver.FindElement(_siteMapButton).Click();
            _webDriver.FindElement(_shippingReturnsButton).Click();
            _webDriver.FindElement(_privacyPolicyButton).Click();
            Thread.Sleep(4000);
            _webDriver.FindElement(_conditionsOfUseButton).Click();
            _webDriver.FindElement(_contactUsFooterButton).Click();
            _webDriver.FindElement(_searchButton).Click();
            Thread.Sleep(4000);
            _webDriver.FindElement(_newsButton).Click();
            _webDriver.FindElement(_blogButton).Click();
            _webDriver.FindElement(_recentlyViewedButton).Click();
            Thread.Sleep(4000);
            _webDriver.FindElement(_compareProductsButton).Click();
            _webDriver.FindElement(_newProductsButton).Click();
            _webDriver.FindElement(_myAccountButton).Click();
            Thread.Sleep(4000);
            _webDriver.FindElement(_ordersButton).Click();
            _webDriver.FindElement(_myAdressesButton).Click();
            _webDriver.FindElement(_wishlistButton).Click();

        }
    }
}
