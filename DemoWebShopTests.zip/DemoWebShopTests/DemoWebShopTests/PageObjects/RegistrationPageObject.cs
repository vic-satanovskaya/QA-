﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DemoWebShopTests.PageObjects
{
    class RegistrationPageObject
    {
        private IWebDriver _webDriver;

        private readonly By _genderCheckBox = By.XPath("//input[@id='gender-female']");
        private readonly By _firstNameInput = By.XPath("//input[@name='FirstName']");
        private readonly By _lastNameInput = By.XPath("//input[@name='LastName']");
        private readonly By _emailWrongInput = By.XPath("//input[@name= 'Email']");
        private readonly By _emailInput = By.XPath("//input[@name='Email']");
        private readonly By _passwordInput = By.XPath("//input[@name= 'Password']");
        private readonly By _confirmPasswordInput = By.XPath("//input[@name= 'ConfirmPassword']");
        private readonly By _registerDoneButton = By.XPath("//input[@name='register-button']");

        
        public RegistrationPageObject(IWebDriver webDriver)
        {
            _webDriver = webDriver;
        }

        public MainMenuPageObject LogIn()
        {
            string _emailWrong = "evil_en_lucifer@mail.ru";
            string _email = "imyoursatan666@gmail.com";
            string _password = "12345678910";
            string _firstname = "Victoria";
            string _lastname = "Satanovskaya";
            _webDriver.FindElement(_genderCheckBox).Click();
            _webDriver.FindElement(_firstNameInput).SendKeys(_firstname);
            _webDriver.FindElement(_lastNameInput).SendKeys(_lastname);
            _webDriver.FindElement(_emailWrongInput).SendKeys(_emailWrong);
            _webDriver.FindElement(_passwordInput).SendKeys(_password);
            _webDriver.FindElement(_confirmPasswordInput).SendKeys(_password);
            _webDriver.FindElement(_registerDoneButton).Click();
            Thread.Sleep(4000);
            _webDriver.FindElement(_emailInput).Clear();
            _webDriver.FindElement(_emailInput).SendKeys(_email);
            _webDriver.FindElement(_registerDoneButton).Click();
            return new MainMenuPageObject(_webDriver);
        }
    }
}
