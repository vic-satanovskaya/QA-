﻿namespace DemoWebShopTests.PageObjects
{
    internal class IwevDriver
    {
    }
}