﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DemoWebShopTests.PageObjects
{
    class ItemsPageObject
    {
        private IWebDriver _webDriver;

        private readonly By _itemButton = By.XPath("//a[@href='/141-inch-laptop']");
        private readonly By _addToCartButton = By.XPath("//input[@id='add-to-cart-button-31']");

        private readonly By _computersButton = By.XPath("//a[@href='/computers']");
        private readonly By _desktopsButton = By.XPath("//a[@href='/desktops']");
        private readonly By _sortDesktopsButton = By.XPath("//select[@id='products-orderby']");
        private readonly By _sortDesktopsAtoZ = By.XPath("//option[@value='http://demowebshop.tricentis.com/desktops?orderby=5']");
        private readonly By _firstItemButton = By.XPath("//a[@href='/build-your-cheap-own-computer']");
        private readonly By _addToCompareButton = By.XPath("//input[@class='button-2 add-to-compare-list-button']");

        private readonly By _giftCardsButton = By.XPath("//a[@href='/gift-cards']");
        private readonly By _giftCard25UsdButton = By.XPath("//a[@href='/25-virtual-gift-card']");
        private readonly By _giftCardAddToCartButton = By.XPath("//input[@id='add-to-cart-button-2']");
        private readonly By _booksButton = By.XPath("//a[@href='/books']");
        private readonly By _bookButton = By.XPath("//a[@href='/computing-and-internet']");
        private readonly By _bookAddToCartButton = By.XPath("//input[@id='add-to-cart-button-13']");
        private readonly By _noteBookButton = By.XPath("//a[@href='/notebooks']");
        private readonly By _apparelShoesButton = By.XPath("//a[@href='/apparel-shoes']");
        private readonly By _blueJeans = By.XPath("//a[@href='/blue-jeans']");
        private readonly By _blueJeansAddToCartButton = By.XPath("//input[@id='add-to-cart-button-36']");
        private readonly By _jewelryButton = By.XPath("//a[@href='/jewelry']");
        private readonly By _jewerlyDiamondButton = By.XPath("//a[@href='/black-white-diamond-heart']");
        private readonly By _jewelryDiamondAddToCartButton = By.XPath("//input[@id='add-to-cart-button-14']");
        private readonly By _cartButton = By.XPath("//span[@class='cart-label']");
        private readonly By _agreementCheckBox = By.XPath("//input[@id='termofservice']");
        private readonly By _checkoutButton = By.XPath("//buton[@id='checkout']");

        private readonly By _countrySelect = By.XPath("//select[@name='BillingNewAddress.CountryId']");
        private readonly By _countryCanadaSelect = By.XPath("//option[@value='2']");
        private readonly By _cityInput = By.XPath("//input[@id='BillingNewAddress_City']");
        private readonly By _adressInput = By.XPath("//input[@id='BillingNewAddress_Address1']");
        private readonly By _zipCodeInput = By.XPath("//input[@id='BillingNewAddress_ZipPostalCode'");
        private readonly By _phoneNumberInput = By.XPath("//input[@id='BillingNewAddress_PhoneNumber']");
        private readonly By _continueButton = By.XPath("//input[@class='button-1 new-address-next-step-button']");
        private readonly By _continueButtonTwo = By.XPath("//input[@class='button-1 shipping-method-next-step-button']");
        private readonly By _creditCartCheckBox = By.XPath("//input[@id='paymentmethod_2']");
        private readonly By _continueButtonThree = By.XPath("//input[@class='button-1 payment-method-next-step-button']");
        private readonly By _cardHolderNameInput = By.XPath("//input[@id='CardholderName']");
        private readonly By _cardNumberInput = By.XPath("//input[@id='CardNumber']");
        private readonly By _cardCodeInput = By.XPath("//input[@id='CardCode']");
        private readonly By _continueButtonFour = By.XPath("//input[@class='button-1 payment-info-next-step-button']");
        private readonly By _continueButtonFive = By.XPath("//input[@button-1 confirm-order-next-step-button']");
        private const string _city = "Toronto";
        private const string _adress = "Street 1-1";
        private const string _zip = "220220";
        private const string _phone = "220220220";
        private const string _cardHolder = "Tori";
        private const string _cardNumber = "344256382143512";
        private const string _cardCode = "333";
        public ItemsPageObject(IWebDriver webDriver)
        {
            _webDriver = webDriver;
        }

        public MainMenuPageObject AddToCart()
        {
            _webDriver.FindElement(_itemButton).Click();
            _webDriver.FindElement(_addToCartButton).Click();
            Thread.Sleep(4000);
            _webDriver.FindElement(_computersButton).Click();
            _webDriver.FindElement(_desktopsButton).Click();
            _webDriver.FindElement(_sortDesktopsButton).Click();
            _webDriver.FindElement(_sortDesktopsAtoZ).Click();
            Thread.Sleep(4000);
            _webDriver.FindElement(_firstItemButton).Click();
            _webDriver.FindElement(_addToCompareButton).Click();
            return new MainMenuPageObject(_webDriver);
            
        }

        public void Shopping ()
        {
            _webDriver.FindElement(_giftCardsButton).Click();
            _webDriver.FindElement(_giftCard25UsdButton).Click();
            _webDriver.FindElement(_giftCardAddToCartButton).Click();
            Thread.Sleep(4000);
            _webDriver.FindElement(_booksButton).Click();
            _webDriver.FindElement(_bookButton).Click();
            _webDriver.FindElement(_bookAddToCartButton).Click();
            Thread.Sleep(4000);
            _webDriver.FindElement(_computersButton).Click();
            _webDriver.FindElement(_noteBookButton).Click();
            _webDriver.FindElement(_itemButton).Click();
            _webDriver.FindElement(_addToCartButton).Click();
            Thread.Sleep(4000);
            _webDriver.FindElement(_apparelShoesButton).Click();
            _webDriver.FindElement(_blueJeans).Click();
            _webDriver.FindElement(_blueJeansAddToCartButton).Click();
            Thread.Sleep(4000);
            _webDriver.FindElement(_jewelryButton).Click();
            _webDriver.FindElement(_jewerlyDiamondButton).Click();
            _webDriver.FindElement(_jewelryDiamondAddToCartButton).Click();
            Thread.Sleep(4000);
            _webDriver.FindElement(_cartButton).Click();
            _webDriver.FindElement(_agreementCheckBox).Click();
            _webDriver.FindElement(_checkoutButton).Click();
            
        }

        public void ContactInformation()
        {
            _webDriver.FindElement(_countrySelect).Click();
            _webDriver.FindElement(_countryCanadaSelect).Click();
            _webDriver.FindElement(_cityInput).SendKeys(_city);
            _webDriver.FindElement(_adressInput).SendKeys(_adress);
            _webDriver.FindElement(_zipCodeInput).SendKeys(_zip);
            _webDriver.FindElement(_phoneNumberInput).SendKeys(_phone);
            Thread.Sleep(4000);
            _webDriver.FindElement(_continueButton).Click();
            _webDriver.FindElement(_continueButtonTwo).Click();
            Thread.Sleep(4000);
            _webDriver.FindElement(_creditCartCheckBox).Click();
            _webDriver.FindElement(_continueButtonThree).Click();
            Thread.Sleep(4000);
            _webDriver.FindElement(_cardHolderNameInput).SendKeys(_cardHolder);
            _webDriver.FindElement(_cardNumberInput).SendKeys(_cardNumber);
            _webDriver.FindElement(_cardCodeInput).SendKeys(_cardCode);
            _webDriver.FindElement(_continueButtonFour).Click();
            _webDriver.FindElement(_continueButtonFive).Click();
        

        }
    }
}
