﻿using DemoWebShopTests.PageObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoWebShopTests
{
    class RandomMessage
    {
        private IWebDriver _webDriver;


        public RandomMessage(IWebDriver webDriver)
        {
            _webDriver = webDriver;
        }

        public void Random(ref string randomWord)
        {
            bool digitOrLetter = false;
            Random random = new Random();
            for (int i = 0; i < 14; i++)
            {
                if (digitOrLetter)
                {
                    randomWord += (char)random.Next(65, 90);
                }
                else
                {
                    randomWord += (char)random.Next(48, 57);
                }
                digitOrLetter = !digitOrLetter;
            }
        }
        
    }
}
