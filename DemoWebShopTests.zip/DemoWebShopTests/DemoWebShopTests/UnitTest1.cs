using DemoWebShopTests.PageObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;

namespace DemoWebShopTests
{
    public class Tests
    {
        private IWebDriver driver;
        private IWebDriver _webDriver;


        [SetUp]
        public void Setup()
        {
            _webDriver = new OpenQA.Selenium.Chrome.ChromeDriver();
            _webDriver.Navigate().GoToUrl("http://demowebshop.tricentis.com/");
            _webDriver.Manage().Window.Maximize();
          
        }

        [Test]
        public void Test1()
        {


            var mainMenu = new MainMenuPageObject(_webDriver);
            mainMenu
                .Registration()
                .LogIn()
                .ContactUs();
            mainMenu.Footer();

            var itemsMenu = new ItemsPageObject(_webDriver);
            itemsMenu.AddToCart();
            itemsMenu.Shopping();
            itemsMenu.ContactInformation();


        }

        [TearDown]
        private void TearDown()
        {
            _webDriver.Quit();
        }
    }
}
